void lights();
void handle_button();
int get_num();
void setup_lights();