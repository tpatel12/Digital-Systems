void init_switch();
int loop_switch();